package melyik_csapat_szine;

import java.util.Scanner;

public class Melyik_csapat_szine {

    public static void main(String[] args) {
        
        String csapat_szin = "piros";
        String csapat_nev = "Ilyen nincs!";
        String h = "Honvéd";
        String f = "Fradi";
        String mv = "Magyar Válogatott";
        if(csapat_szin == "piros"){
            csapat_nev = mv + " , " + h;
        }else if(csapat_szin == "fehér"){
            csapat_nev = mv + " , " + f + " , " + h;
        }else if(csapat_szin == "zöld"){
            csapat_nev = mv + " , " + h;
        }
        System.out.println("A választott szined csapata: "+ csapat_nev);
        
        
        
        /*
        Scanner sc = new Scanner(System.in);
        System.out.println("Milyen színű csapatnak szurkolsz?");
        String csapat_szin = sc.nextLine();
        System.out.println(csapat_szin);
        String csapat_nev = "Ilyen nincs!";
        String h = "Honvéd";
        String f = "Fradi";
        String mv = "Magyar Válogatott";
        if(csapat_szin == "piros"){
            csapat_nev = mv + " , " + h;
        }else if(csapat_szin == "fehér"){
            csapat_nev = mv + " , " + f + " , " + h;
        }else if(csapat_szin == "zöld"){
            csapat_nev = mv + " , " + h;
        }
        System.out.println("A választott szined csapata: "+ csapat_nev);
        */
        
    }
    
}
