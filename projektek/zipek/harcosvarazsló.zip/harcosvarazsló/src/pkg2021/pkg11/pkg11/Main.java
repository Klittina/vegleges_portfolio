package pkg2021.pkg11.pkg11;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        //Életerők számolása
        //Ügyesség
        Random rnd = new Random();
        int ugyesseg = rnd.nextInt(6) + 1;
        ugyesseg = ugyesseg + 6;
        System.out.printf("Az ügyességed egy random szám plusz hat lesz, melynek az eredménye:%d \n", ugyesseg);
        int eletero = rnd.nextInt(11) + 2;
        eletero = eletero + 12;
        System.out.printf("Az élterőd pontja: %d\n", eletero);
        int szerencse = rnd.nextInt(6) + 1;
        szerencse = szerencse + 6;
        System.out.printf("Az szerencséd pontja: %d\n", szerencse);
        System.out.print("Ez nem is lesz egy rossz kezdés. Játszunk.");
        System.in.read();
        //Halállabirintus
        System.out.print("Egy versenyre nevezel, aminek a lényege, hogy át kell kelni a halállabirintuson. A labirintusban tárgyakat találhatsz és szörnyekkel kell harcoljál. ");
        System.in.read();
        System.out.println("Miután öt percet haladtál lassan az alagútban, egy kőasztalhoz érsz, amely a bal oldali fal mellett áll. \nHat doboz van rajta, egyikükre a te neved festették. Ha kiakarod nyitni a dobozt, lapozz a 270-re. Ha inkább tovább haladsz észak felé, lapozz a 66-ra. ");
        Scanner scn = new Scanner(System.in);
        Scanner scnstring = new Scanner(System.in);
        int oldal = scn.nextInt();
        if (oldal == 270) {
            System.out.println("A doboz teteje könnyedén nyílik. Benne két aranypénzt találsz, és egy üzenetet, amely egy kis pergamenen neked szól.\nElőbb zsebre vágod az aranyakat, aztán elolvasod az üzenetet: \n- „Jól tetted. Legalább volt annyi eszed, hogy megállj és elfogadd az ajándékot. Most azt tanácsolom neked, hogy keress és használj különféle tárgyakat, \nha sikerrel akarsz áthaladni Halállabirintusomon.” Azaláírás Szukumvit. Megjegyzed a tanácsot, apródarabokra téped a pergament, és tovább mészészak felé. Lapozz a 66-ra. ");
            
        }
        System.out.println("66. oldal \n"
                + "\n"
                + "Néhány perc gyaloglás után egy elágazáshoz érsz az alagútban. Egy, a falra festett fehér nyíl nyugatfelé mutat. \nA földön nedves lábnyomok jelzik, merre haladtak az előtted járók. Nehéz biztosan megmondani, \nde úgy tűnik, hogy három közülük a nyíl irányába halad, míg egyikük úgy döntött, \nhogy keletnek megy. Ha nyugat felé kívánsz menni, lapozz a 293-ra. Ha keletnek, lapozz a 56-re. ");
        oldal = scn.nextInt();
        if (oldal == 293) {
            System.out.println("A három pár nedves lábnyomot követve az alagútnyugati elágazásában hamarosan egy újabb el-ágazáshoz érsz. Ha továbbmész nyugat felé a lábnyomokat követve, lapozz a 137-re. \nHa inkább észak felé mész a harmadik pár lábnyom után, lapozz a 387-re. ");
            oldal = scn.nextInt();
            if (oldal == 137) {
                System.out.println("Ahogy végigmész az alagúton, csodálkozva látod, hogy egy jókora vasharang csüng alá a boltozatról. ");
                System.in.read();
            } else if (oldal == 387) {
                System.out.print("\nHallod, hogy elölről súlyos lépések közelednek. Egy széles, állatbőrökbe öltözött, kőbaltás, primitívlény lép elő. \nAhogy meglát, morog, a földre köp, majd a kőbaltát felemelve közeledik, és mindennek kinéz, csak barátságosnak nem. \nElőhúzod kardodat, és felkészülsz, hogy megküzdj a Barlangi Emberrel. ");
                System.in.read();
                //harc
                int teremtmeny_eletero = 7;
                int teremtmeny_tamadas;
                do {
                    int probaszerencse;
                    String veglegesdontes;
                    teremtmeny_tamadas = rnd.nextInt(11) + 2 + 7;
                    int tamadoero = ugyesseg + rnd.nextInt(11) + 2;
                    //szerencse
                    System.out.println("Fogod használni a szerencsédet?");
                    String dontes = scnstring.nextLine();
                    if (dontes.equals("igen") || dontes.equals("IGEN") || dontes.equals("Igen")) {
                        System.out.println("Mire fogod használni a szerencsédet? A szörnyet sebzed meg, vagy megvéded magad? Írd be hogy attack vagy defense a választásod.");
                        veglegesdontes = scnstring.nextLine();

                        probaszerencse = rnd.nextInt(11) + 2;
                        if (probaszerencse <= szerencse) {
                            System.out.println("Szerencséd van");
                            if (veglegesdontes.equals("defense")) {
                                if (teremtmeny_tamadas < tamadoero) {
                                    teremtmeny_eletero -= 2;
                                    System.out.printf("Te nyerted a harcot az életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                                } else if (teremtmeny_tamadas > tamadoero) {
                                    eletero -= 1;
                                    System.out.printf("A szörny nyerte a harcot te életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                                } else if (teremtmeny_tamadas == tamadoero) {
                                    System.out.printf("Döntetlen, te életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                                }
                            } else if (veglegesdontes.equals("attack")) {
                                if (teremtmeny_tamadas < tamadoero) {
                                    teremtmeny_eletero -= 4;
                                    System.out.printf("Te nyerted a harcot az életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                                } else if (teremtmeny_tamadas > tamadoero) {
                                    eletero -= 2;
                                    System.out.printf("A szörny nyerte a harcot te életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                                } else if (teremtmeny_tamadas == tamadoero) {
                                    System.out.printf("Döntetlen, te életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                                }

                            } else {
                                System.out.println("Hülye választ nem fogadunk el, buktad a szerencsédet, és még le is vonjuk tőled <3");
                                if (teremtmeny_tamadas < tamadoero) {
                                    teremtmeny_eletero -= 2;
                                    System.out.printf("Te nyerted a harcot az életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                                } else if (teremtmeny_tamadas > tamadoero) {
                                    eletero -= 2;
                                    System.out.printf("A szörny nyerte a harcot te életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                                } else if (teremtmeny_tamadas == tamadoero) {
                                    System.out.printf("Döntetlen, te életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                                }
                            }
                        } else {
                            System.out.println("Nincs szerencséd");
                            if (teremtmeny_tamadas < tamadoero) {
                                teremtmeny_eletero -= 2;
                                System.out.printf("Te nyerted a harcot az életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                            } else if (teremtmeny_tamadas > tamadoero) {
                                eletero -= 3;
                                System.out.printf("A szörny nyerte a harcot te életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                            } else if (teremtmeny_tamadas == tamadoero) {
                                System.out.printf("Döntetlen, te életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                            }

                        }
                        szerencse--;

                    } else {
                        System.out.println("Nem használsz szerencsét.");
                        if (teremtmeny_tamadas < tamadoero) {
                            teremtmeny_eletero -= 2;
                            System.out.printf("Te nyerted a harcot az életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                        } else if (teremtmeny_tamadas > tamadoero) {
                            eletero -= 2;
                            System.out.printf("A szörny nyerte a harcot te életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                        } else if (teremtmeny_tamadas == tamadoero) {
                            System.out.printf("Döntetlen, te életerőd: %d a szörny életereje: %d\n", eletero, teremtmeny_eletero);
                        }
                    }

                } while (!((eletero == 0) || (teremtmeny_eletero <= 0)));
            }
        } else if (oldal == 56) {
            System.out.println("Látod, hogy az akadály egy széles, barna, sziklaszerű tárgy. Megérinted, és meglepve tapasztalod, hogy lágy, szivacsszerű.\n Ha át szeretnél mászni rajta, lapozz a 373-ra. \nHa ketté akarod vágni a kardoddal, lapozz a 215-re");
            oldal = scn.nextInt();
            if (oldal == 373) {
                System.out.println("Fölmászol a lágy sziklára, attól tartasz, hogy bár-melyik pillanatban elnyelhet. \nNehéz átvergődni rajta, mert puha anyagában alig tudod a lábadat emelni, de végül átvergődsz rajta. \nMegkönnyebbülten érsz újra szilárd talajra, és fordulsz kelet felé. ");
            } else if (oldal == 215) {
                System.out.println("Kardod könnyedén áthatol a spóragolyó vékonykülső burkán. Sűrű barna spórafelhő csap ki a golyóból, és körülvesz. \nNémelyik spóra a bőrödhöz tapad, és rettenetes viszketést okoz. \nNagy daganatok nőnek az arcodon és karodon, és a bőröd mintha égne. \n2 ÉLETERŐ pontot veszítesz. Vadul vakarózva átléped a leeresztett golyót, és keletnek veszed az utad. ");
                eletero-=2;
            }

        }
        System.out.printf("A játék végén megnézzük hogyan alakultak a pontjaid:\nAz életerőd: %d \nA szerencséd: %d \nAz ügyességed: %d\n", eletero , szerencse, ugyesseg );
    }

}
