package feltetelek;
public class Feltetelek1_Relaciok {
    public static void main(String[] args) {
        System.out.println("Feltételek relációja:");
        //System.out.println("3 < 5 " + (3 < 5));
        System.out.printf("3 < 5 %b\n", 3 < 5);
        System.out.printf("3 > 5 %b\n", 3 > 5);
        System.out.printf("3 <= 5 %b\n", 3 <= 5);
        System.out.printf("3 >= 5 %b\n", 3 >= 5);
        System.out.printf("3 == 5 %b\n", 3 == 5);
        System.out.printf("3 != 5 %b\n", 3 != 5);
        
        System.out.println("Feltételek változókkal:");
        int szam1 = 3, szam2 = 5;
        System.out.printf("%d < %d %b\n", szam1, szam2, szam1 < szam2);
        
        boolean feltetel = szam1 == szam2;
        System.out.printf("%d == %d %b\n", szam1, szam2, feltetel);
    }
    
}
