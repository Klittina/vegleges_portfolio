package feltetelek;
public class Feltetelek3_if {
    public static void main(String[] args) {
        /* gyakorlás: 
        * minden boolean változót írj át:
        * true majd false értékre is
        */    
        boolean esik = false;
        //1.: csak igaz ág:
        if(esik == true){
            System.out.println("Esik az eső");
        }
        System.out.println("1. elágazás vége");
        
        System.out.println("---------------");
        
        //2.: igaz és hamis ággal:
        if(esik == false){
            System.out.println("NEM Esik az eső");
        }else{
            System.out.println("Esik az eső");
        }
        System.out.println("2. elágazás vége");
        
        System.out.println("PRG. vége");
    }
}
