package elegemvan;

public class Elegemvan {

    public static void main(String[] args) {
       /* lehetséges értékek: piros, fehér,zöld */ 
        String szin = "pirfghjos";
        
        /* EREDETI */
        if(szin == "piros"){
            System.out.println("a \"piros\" színt adtad meg!");
        }else if(szin == "fehér"){
            System.out.println("a \"fehér\" színt adtad meg!");
        }else if(szin == "zöld"){
            System.out.println("a \"zöld\" színt adtad meg!");
        }else{
            System.out.println("NEM TUDOM!");
        }
        
        /*1.: REFAKTORIZÁLT kód */
        String valasz = "NEM TUDOM!";
        if(szin == "piros"){
            valasz = "a \"piros\" színt adtad meg!";
        }else if(szin == "fehér"){
            valasz = "a \"fehér\" színt adtad meg!";
        }else if(szin == "zöld"){
            valasz = "a \"zöld\" színt adtad meg!";
        }
        
        System.out.println("**********");
        System.out.println(valasz);
        System.out.println("**********");
        
        /*2.: REFAKTORIZÁLT kód */
        valasz = "NEM TUDOM!";
        if(szin == "piros"){
            valasz = "a \"" + szin + "\" színt adtad meg!";
        }else if(szin == "fehér"){
            valasz = "a \"" + szin + "\" színt adtad meg!";
        }else if(szin == "zöld"){
            valasz = "a \"" + szin + "\" színt adtad meg!";
        }
        
        System.out.println("**********");
        System.out.println(valasz);
        System.out.println("**********");
        
        /*3.: REFAKTORIZÁLT kód */
        String valasztottSzin = "NEM TUDOM!";
        if(szin == "piros"){
            valasztottSzin = szin;
        }else if(szin == "fehér"){
            valasztottSzin = szin;
        }else if(szin == "zöld"){
            valasztottSzin = szin;
        }
        System.out.println("**********");
        valasz = "a |" + szin + "| színt adtad meg!";
        System.out.println(valasz);
        System.out.println("**********");
        
        /*4.: REFAKTORIZÁLT kód */
        valasztottSzin = "NEM TUDOM!";
        if(szin == "piros" || szin == "fehér" || szin == "zöld"){
            valasztottSzin = szin;
        }
        System.out.println("**********");
        valasz = "a |" + valasztottSzin + "| színt adtad meg!";
        System.out.println(valasz);
        System.out.println("**********"); 
    }
    
}
