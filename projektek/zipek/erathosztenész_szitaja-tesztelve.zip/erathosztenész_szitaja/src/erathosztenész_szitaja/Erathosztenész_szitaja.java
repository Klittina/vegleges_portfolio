package erathosztenész_szitaja;

import java.io.IOException;
import java.util.Scanner;
import java.lang.Math;

public class Erathosztenész_szitaja {

    public static void main(String[] args) throws IOException {
        //Krisztina jegyzetek
        //A program alján lévő kikommentelt részeket az 5. csapat írta, és szándékosan kommenteltem ki, ugyanis csak a lenti módón tudtam megoldani a többszörös bekérést, viszont azt se akartam hogy az eredeti kód ne legyen benne valamilyen formában a végleges verzióban.
        Scanner sc = new Scanner(System.in);
        int bekert;  //már itt megkellett adnom a bekert változót egy bármilyen random értékkel hogy később meg tudjam hívni a do-ba
        int rosszvalasz = 0; //3 rossz válasz után megy az else ágba, az else if be meg mindig eggyel növekszik
        do {
        System.out.print("Add meg meddig szeretnéd megtudni a prímszámokat: ");
        bekert = sc.nextInt();
            if (bekert == 100 || bekert == 121 || bekert == 144 || bekert == 169 || bekert == 196 || bekert == 225){
                System.out.println(bekert + " egy jó szám.");
                System.out.println(" ");
                
                int primszamtomb = bekert;  
        
                boolean[] szamok = new boolean[primszamtomb];
                szamok[0] = false;
                for (int i = 1; i < szamok.length; i++) {
                szamok[i] = true;
                }
                int p = 2;
                while(Math.pow(p, 2) < primszamtomb){
                if (szamok[p]) {
                  int j = (int)Math.pow(p, 2);
                
                   while(j < primszamtomb){
                    szamok[j] = false;
                    j = j + p;
                }
            }
            p++;
        }
        int db = 0;
        for (int i = 1; i < szamok.length; i++) {
            if (db % 10 == 9) {
                System.out.println(i + " ");
            }
            else{
                System.out.print(i + " ");
            }
            db++;
        }
        System.out.println("");
        
        System.out.print("Eratoszthenész szitája a neves ókori görög matematikus, Eratoszthenész módszere,\n melynek segítségével egyszerű kizárásos algoritmussal megállapíthatjuk, hogy melyek a prímszámok.");
        System.in.read();
        System.out.print("Az elnevezés utal az eljárás lényegére, mivel az 1-től n-ig felírt egész számok közül “kiszitáljuk” az összetett számokat.\n Amely számok fennmaradnak a “szitán” (az 1 kivételével) azok a prímek.");
        System.in.read();
        System.out.println("Ezt általában 1 és 100 között szokták csinálni, viszont a te számod a " + bekert + ". \nDe természetesen minket ez nem fog elriasztani.");
        System.in.read();
        System.out.println("Kezdésnek mindig a 2-vel kell kezdenünk, majd minden 2-vel osztható számot át kell húznunk a táblázatban.\n Viszont itt most egy * jelet rakunk a helyükre.");
        System.in.read();
        /*
        //Krisztina jegyzetek
        Font font = new Font("helvetica", Font.PLAIN, 12);
        Map  attributes = font.getAttributes();
        attributes.put(TextAttribute.STRIKETHROUGH, TextAttribute.STRIKETHROUGH_ON);
        Font newFont = new Font(attributes); 
        
        elméletileg a szöveg áthuzásához ezt kellene használni plusz importálni viszont nem igazán értem, így csak itthagyom ilyen lábjegyzetnek, hátha egyszer majd sikerülni fog.
        */
        while(Math.pow(p, 2) < primszamtomb){
            if (szamok[p]) {
                int j = (int)Math.pow(p, 2);
                
                while(j < primszamtomb){
                    szamok[j] = false;
                    j = j + p;
                }
            }
            p++;
        }
        int db1 = 0;
        for (int i = 1; i < szamok.length; i++) {
            if (db1 % 10 == 9) {
                System.out.println( "* ");
            }else if (db1 % 2 == 1 & db1 > 2){
                System.out.print("* ");
            }else{
                System.out.print(i + " ");
            }
            db1++;
        }
        System.out.println("");
        System.in.read();
        System.out.println("Látod, nem is volt ez olyan nehéz. Most próbáljuk ki a hárommal is.");
        System.in.read();
        
         while(Math.pow(p, 2) < primszamtomb){
            if (szamok[p]) {
                int j = (int)Math.pow(p, 2);
                
                while(j < primszamtomb){
                    szamok[j] = false;
                    j = j + p;
                }
            }
            p++;
        }
        int db2 = 0;
        for (int i = 1; i < szamok.length; i++) {
            if (db2 % 10 == 9) {
                System.out.println( "* ");
            }else if (db2 % 2 == 1 & db2 > 2) {
               System.out.print( "* ");
            }else if (db2 % 3 == 2 & db2 > 3) {
               System.out.print( "* ");
            }else{
                System.out.print(i + " ");
            }
            db2++;
        }
        System.out.println("");
        System.in.read();
        System.out.println("Egyre több csillagunk van a táblázatban, nem igaz?");
        System.in.read();
        System.out.println("Próbáluk ki ezt a módszert még az ötössel is! ");
        System.in.read();
        while(Math.pow(p, 2) < primszamtomb){
            if (szamok[p]) {
                int j = (int)Math.pow(p, 2);
                
                while(j < primszamtomb){
                    szamok[j] = false;
                    j = j + p;
                }
            }
            p++;
        }
        int db3 = 0;
        for (int i = 1; i < szamok.length; i++) {
            if (db3 % 10 == 9) {
                System.out.println( "* ");
            }else if (db3 % 2 == 1 & db3 > 2) {
               System.out.print( "* ");
            }else if (db3 % 3 == 2 & db3 > 3) {
               System.out.print( "* ");
            }else if (db3 % 5 == 4 & db3 > 5) {
               System.out.print( "* ");
            }else{
                System.out.print(i + " ");
            }
            db3++;
        }
        System.in.read();
        //Krisztina jegyzetek
        //itt eredetileg egy string lett volna amire igennel vagy nemmel lehetett volna válaszolni viszont valamiért azt nem vette be a scanner, így hát maradt a régi jól bevált 1 éa 2
        //talán egy kicsit proli meg etc de igyis sokkal többet hoztam ki magamból mint amire gondolni mertem volna, sooo actually i am really proud of myself <3
        int valasz;
                System.out.println("Szeretnéd kipróbálni ezt a módszert a héttel is? 1-igen / 2-nem");
                valasz = sc.nextInt();
          if (valasz==1){
              System.in.read();
              System.out.println("Igent válaszoltál a kérdésre, így nézzük meg, hogy néz ki ha a hetes többszöröseit is becsillagozzuk. ");
              
              
            while(Math.pow(p, 2) < primszamtomb){
            if (szamok[p]) {
                int j = (int)Math.pow(p, 2);
                
                while(j < primszamtomb){
                    szamok[j] = false;
                    j = j + p;
                }
            }
            p++;
          }
          int db4 = 0;
          for (int i = 1; i < szamok.length; i++) {
            if (db4 % 10 == 9) {
                System.out.println( "* ");
            }else if (db4 % 2 == 1 & db4 > 2) {
               System.out.print( "* ");
            }else if (db4 % 3 == 2 & db4 > 3) {
               System.out.print( "* ");
            }else if (db4 % 5 == 4 & db4 > 5) {
               System.out.print( "* ");
            }else if (db4 % 7 == 6 & db4 > 7) {
               System.out.print( "* ");
            }else{
                System.out.print(i + " ");
            }
            db4++;
          }
          System.in.read();
          System.out.println("Mostmár biztos készen állsz rá hogy egyedül megoldd a feladatot. Az enter billentyű lenyomása után le tudod majd ellenőrizni a megoldásaidat. :)");
        }else {
            System.out.println("Rendben. Csináld végig, majd ha készen vagy, akkor az enter billentyű lenyomása után le tudod ellenőrizni a válaszaidat :)");
        
        }
        
        System.in.read();
        System.out.println("A fenti felsorolt számok közül ezek a prímszámok: ");
        for (int i = 0; i < szamok.length; i++) {
            if (szamok[i]) {
                System.out.print(i + " ");
            }
        }
        System.out.println("");
        //Krisztina jegyzetek
        break; // ha idáig eljut a kód akkor itt automatikusan törik egyet és kilép az egész ciklusból.
        }else if (rosszvalasz < 3){
                System.out.println("Ez sajnos egy rossz szám. Írj be egy másikat.");
                rosszvalasz = 1 + rosszvalasz;
        }else{
                System.out.println("Látom nem érted. A beírt számnak a 10 éa a 15 közötti számok négyzetének kell lennie.");
        }
        }
        while ((bekert != 100) || (bekert != 121) || (bekert != 144) || (bekert != 169) || (bekert != 196) || (bekert != 225));
        
    //Krisztina jegyzetek
    /*
        System.out.print("Add meg meddig szeretnéd megtudni a prímszámokat: ");
        Scanner sc = new Scanner(System.in);
        String bekert = sc.nextLine();
        int primszamtomb = Integer.parseInt(bekert);

        boolean[] szamok = new boolean[primszamtomb];
    
        szamok[0] = false;
        
        for (int i = 1; i < szamok.length; i++) {
            szamok[i] = true;
        }
        
        int p = 2;
        while(Math.pow(p, 2) < primszamtomb){
            if (szamok[p]) {
                int j = (int)Math.pow(p, 2);
                
                while(j < primszamtomb){
                    szamok[j] = false;
                    j = j + p;
                }
            }
            p++;
        }
        int db = 0;
        for (int i = 1; i < szamok.length; i++) {
            if (db % 10 == 9) {
                System.out.println(i + " ");
            }
            else{
                System.out.print(i + " ");
            }
            db++;
        }
        System.out.println("");
        
        System.out.println("A fenti felsorolt számok közül ezek a prímszámok: ");
        for (int i = 0; i < szamok.length; i++) {
            if (szamok[i]) {
                System.out.print(i + " ");
            }
        }
        System.out.println("");
        */
    }
}
