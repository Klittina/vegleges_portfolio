package szamitasok2;

public class Szamitasok2 {

    public static void main(String[] args) {
        System.out.println(3+7);
        System.out.println(3-7);
        
        System.out.println(3+7 + " = 3+7");
        System.out.println(3-7 + " = 3-7");
        
        System.out.println("3-7 = " + (3-7));
        System.out.println("3+7 = " + (3+7));
        
        /* JAVASOLT HASZNÁLAT: */
        System.out.printf("3*7 = %d\n", 3*7);
        System.out.printf("7/3 = %d\n", 7/3);
        System.out.printf("3-7 = %d\n", 3-7);
        System.out.printf("3+7 = %d\n", 3+7);
    }
    
}
