package valtozoktipusai;

public class ValtozokTipusai {

    public static void main(String[] args) {
        System.out.println("Szia Péter!");
        System.out.println("Szia " + "Péter" + "!");
        
        /* SZÖVEG */
        String nev = "Péter";
        System.out.println("Szia " + nev + "!");
        
        String egyBetu = "a";
        egyBetu = "xyz";//ROSSZ: elnevezés megtévesztő!!!
        egyBetu = "x";//ez rendben van
        
        String ures = "";
        String szokoz = " ";
        String szamok;
        szamok = "1234";
        szamok = "1-2-3-4";
        
        char csakEgyBetu = 'x';
        //csakEgyBetu = '';//üres: NEM lehet
        csakEgyBetu   = ' ';//szóköz: ok
        csakEgyBetu   = '\n';//enter: ok
        csakEgyBetu   = '7';//1jegyű szám: ok
        //csakEgyBetu   = '17';//többjegyű szám: NEM lehet
        
        /* SZÁMOK */
        int egesz = 10;
        double tort = 3.124;
        egesz = -5;
        tort = egesz * tort;
        System.out.println("egész értéke: " + egesz);
        System.out.println("tört értéke: " + tort);
    }
    
}

