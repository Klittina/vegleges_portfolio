package szamolasvaltozokkal;

public class SzamolasValtozokkal {

    public static void main(String[] args) {
        int szam1 = 3, szam2 = 7;
        System.out.println(szam1 + "+" + szam2 + " = " + (szam1 + szam2));
        System.out.println(szam1 + "-" + szam2 + " = " + (szam1 - szam2));
        
        /* JAVASOLT: */
        //                  1  2    3       1      2         3
        System.out.printf("%d+%d = %d\n", szam1, szam2, szam1+szam2);
        System.out.printf("%d-%d = %d\n", szam1, szam2, szam1-szam2);
    }
    
}
